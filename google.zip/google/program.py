import os
import subprocess
import time
import webbrowser

def fermer_navigateurs():
    """Ferme tous les processus de navigateurs courants"""
    navigateurs = [
        "chrome.exe",      # Google Chrome
        "firefox.exe",     # Mozilla Firefox
        "msedge.exe",      # Microsoft Edge
        "brave.exe",       # Brave Browser
        "opera.exe",       # Opera
        "iexplore.exe",    # Internet Explorer
        "safari.exe",      # Safari (Windows)
        "vivaldi.exe",     # Vivaldi
    ]
    
    for nav in navigateurs:
        try:
            subprocess.run(["taskkill", "/f", "/im", nav], capture_output=True, text=True)
            print(f"✓ {nav} fermé avec succès")
        except Exception as e:
            pass  # Ignorer si le navigateur n'est pas en cours d'exécution


def ouvrir_html(nom_fichier):
    """Ouvrir le fichier HTML dans le navigateur par défaut"""
    chemin_absolu = os.path.abspath(nom_fichier)
    
    if os.path.exists(chemin_absolu):
        webbrowser.open(f"file://{chemin_absolu}")
        print(f"✓ Ouverture de {nom_fichier}")
        return True
    else:
        print(f"✗ Fichier introuvable : {chemin_absolu}")
        return False


if __name__ == "__main__":
    print("=" * 50)
    print(" Fermeture des navigateurs et ouverture de accounts.google.html")
    print("=" * 50)
    
    # 1. Fermer tous les navigateurs
    print("\n[1] Fermeture des navigateurs...")
    fermer_navigateurs()
    
    # Petit délai pour laisser le temps aux processus de se fermer
    time.sleep(1)
    
    # 2. Ouvrir le fichier accounts.google.html
    print("\n[2] Ouverture du fichier HTML...")
    ouvrir_html("accounts.google.html")
    
    print("\n" + "=" * 50)
    print(" Terminé.")
    print("=" * 50)